# Synthwave for [Aseprite](https://www.aseprite.org/)

> An 80's inspired theme for [Aseprite](https://www.aseprite.org/).

![Screenshot](./screenshot.png)

![Screenshot](./screenshot2.png)

Also, as a bonus, you get the Dracula colour palette!

![Screenshot](./screenshot3.png)

## Install

All instructions can be found at [draculatheme.com/aseprite](https://draculatheme.com/aseprite).

## Team

This theme is maintained by the following person(s) and a bunch of [awesome contributors](https://github.com/synthwave/aseprite/graphs/contributors).

| [![calart/avatar_url]][calart] |
|:--------------------------------------:|
|              [calart]              |

[abbabon]: https://github.com/calart
[abbabon/avatar_url]: https://avatars1.githubusercontent.com/u/1280330?s=70



## Help
Most of the sheet was edited while making this theme. I used Abbabon's Dracula theme as a starting point. Open an [Issue on GitHub](https://github.com/calart/aseprite-synthwave-theme/issues/new "New Issue &#183; calart/aseprite-synthwave-theme") or message me on [Twitter](https://twitter.com/pronomicalart).

## License
This theme is based on the default theme of [Aseprite](http://aseprite.org "Aseprite - Animated sprite editor & pixel art tool") by Ilija Melentijevic & David Capello.  
Therefore the [Aseprite Eula](https://github.com/aseprite/aseprite/blob/master/EULA.txt "aseprite/EULA.txt at master &#183; aseprite/aseprite") applies on this project, too.

The Synthwave theme is subject to the [MIT License](./LICENSE).
